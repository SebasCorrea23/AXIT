using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HVJuanCorrea.Views.Home
{
    public class CualidadesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
